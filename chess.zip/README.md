This is our CS246 chess project.

